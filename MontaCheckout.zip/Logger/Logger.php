<?php

namespace Montapacking\MontaCheckout\Logger;
class Logger extends \Monolog\Logger
{
}
