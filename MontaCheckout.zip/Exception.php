<?php
namespace Montapacking\MontaCheckout;

/**
 * Class Exception
 *
 * @package Montapacking\MontaCheckout
 */
class Exception extends \Exception
{
}
